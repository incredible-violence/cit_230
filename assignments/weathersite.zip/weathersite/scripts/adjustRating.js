function adjustRating(rating) {
    document.getElementById("ratingvalue").innerhtml = rating;
}
