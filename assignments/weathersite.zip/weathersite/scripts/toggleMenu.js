function toggleMenu() {
 document.getElementById('primaryNav').classList.toggle('hide');
}
